// API Configuration
const API_URL = 'http://localhost:3000/api';

// Load site config on page load
document.addEventListener('DOMContentLoaded', async () => {
  await loadSiteConfig();
  await updateTotalOrders();
  
  // Setup form submit handler
  const registerForm = document.getElementById('registerForm');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      await registerOrder();
    });
  }
});

async function loadSiteConfig() {
  try {
    const response = await fetch(`${API_URL}/public/config`);
    const config = await response.json();
    
    const addressEl = document.getElementById('contactAddress');
    const emailEl = document.getElementById('contactEmail');
    const instagramEl = document.getElementById('contactInstagram');
    const hoursEl = document.getElementById('contactHours');
    
    if (addressEl) addressEl.textContent = config.company_address || 'R. Otávio de Souza Brito, 43, Porto Amazonas - PR';
    if (emailEl) emailEl.textContent = config.contact_email || 'cell.consertos.pa@gmail.com';
    if (instagramEl) instagramEl.textContent = config.instagram || '@cell.conserto.pa';
    if (hoursEl) hoursEl.textContent = config.business_hours || 'Aberto 24 horas';
    
    if (config.site_notice && config.site_notice.trim()) {
      const noticeDiv = document.createElement('div');
      noticeDiv.className = 'alert alert-warning';
      noticeDiv.textContent = config.site_notice;
      const heroContent = document.querySelector('.hero-content');
      if (heroContent && !document.querySelector('.site-notice')) {
        noticeDiv.classList.add('site-notice');
        heroContent.prepend(noticeDiv);
      }
    }
  } catch (error) {
    console.error('Erro ao carregar configurações:', error);
  }
}

async function updateTotalOrders() {
  // Placeholder - em produção, criar um endpoint público para isso
  document.getElementById('totalOrders').textContent = '100+';
}

async function registerOrder() {
  const name = document.getElementById('regName').value.trim();
  const phone = document.getElementById('regPhone').value.trim();
  const device = document.getElementById('regDevice').value.trim();
  const service = document.getElementById('regService').value;
  const description = document.getElementById('regDesc').value.trim();
  const alertDiv = document.getElementById('registerAlert');

  if (!name || !phone || !device || !service || !description) {
    showAlert(alertDiv, '⚠️ Preencha todos os campos obrigatórios.', 'error');
    return;
  }

  if (name.length < 3) {
    showAlert(alertDiv, '⚠️ Nome muito curto.', 'error');
    return;
  }

  const phoneClean = phone.replace(/\D/g, '');
  if (phoneClean.length < 10) {
    showAlert(alertDiv, '⚠️ Telefone inválido.', 'error');
    return;
  }

  // Show loading state
  const submitBtn = document.querySelector('#registerForm button[type="submit"]');
  const originalText = submitBtn.textContent;
  submitBtn.textContent = '⏳ Enviando...';
  submitBtn.disabled = true;

  try {
    const response = await fetch(`${API_URL}/public/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, phone, device, service, description })
    });

    const data = await response.json();

    if (response.status === 403) {
      let message = `❌ Seu telefone está bloqueado. Motivo: ${data.reason}`;
      if (data.expires) {
        message += `\nBloqueio válido até: ${new Date(data.expires).toLocaleDateString('pt-BR')}`;
      }
      showAlert(alertDiv, message, 'error');
      return;
    }

    if (response.ok && data.success) {
      showAlert(alertDiv, `✅ Chamado aberto! Protocolo: <strong>${data.protocol}</strong><br>Aguardando análise do administrador. Guarde este código para rastrear.`, 'success');
      document.getElementById('registerForm').reset();
      toast(data.protocol, 'success');
    } else if (data.errors) {
      showAlert(alertDiv, `❌ ${data.errors[0].msg}`, 'error');
    } else {
      showAlert(alertDiv, `❌ ${data.error || 'Erro ao abrir chamado'}`, 'error');
    }
  } catch (error) {
    console.error('Erro:', error);
    showAlert(alertDiv, '❌ Erro de conexão. Verifique se o servidor está rodando em http://localhost:3000', 'error');
  } finally {
    submitBtn.textContent = originalText;
    submitBtn.disabled = false;
  }
}

async function trackOrder() {
  const protocol = document.getElementById('trackProtocol').value.trim().toUpperCase();
  const resultDiv = document.getElementById('trackResult');

  if (!protocol) {
    resultDiv.innerHTML = '<div class="alert alert-error">Digite o protocolo.</div>';
    return;
  }

  resultDiv.innerHTML = '<div class="alert alert-warning">🔍 Buscando...</div>';

  try {
    const response = await fetch(`${API_URL}/public/track/${encodeURIComponent(protocol)}`);
    
    if (response.status === 404) {
      resultDiv.innerHTML = '<div class="alert alert-error">❌ Protocolo não encontrado. Verifique o código e tente novamente.</div>';
      return;
    }

    const data = await response.json();

    if (!response.ok) {
      resultDiv.innerHTML = `<div class="alert alert-error">❌ ${data.error || 'Erro ao buscar chamado'}</div>`;
      return;
    }

    const { order, timeline } = data;

    if (order.status === 'Recusado') {
      resultDiv.innerHTML = `
        <div class="status-card" style="border-left-color: var(--danger)">
          <div class="status-header">
            <div><strong>${order.protocol}</strong><br><span style="color:var(--text-muted);font-size:.8rem">${order.device} · ${order.service}</span></div>
            <span class="status-badge status-rejected">❌ Recusado</span>
          </div>
          ${order.note ? `<div style="background:rgba(239,68,68,0.08);border-radius:8px;padding:.75rem;margin-bottom:1rem;font-size:.85rem;border-left:3px solid var(--danger)">💬 <strong>Motivo da recusa:</strong> ${order.note}</div>` : ''}
          <div style="margin-top:1rem;font-size:.75rem;color:var(--text-muted)">Aberto em: ${new Date(order.created_at).toLocaleString('pt-BR')}</div>
        </div>
      `;
      return;
    }

    const steps = ['Aguardando Recebimento', 'Em Análise', 'Em Reparo', 'Pronto para Retirada', 'Entregue'];
    const currentIndex = steps.indexOf(order.status);
    
    const timelineHTML = steps.map((step, i) => {
      const isCompleted = i < currentIndex;
      const isCurrent = i === currentIndex;
      const dotClass = isCompleted ? 'dot-done' : (isCurrent ? 'dot-active' : 'dot-pending');
      const icon = isCompleted ? '✓' : (isCurrent ? '●' : '');
      const timelineEvent = timeline?.find(t => t.event === step || t.event === `Status: ${step}`);
      
      return `
        <div class="timeline-item">
          <div class="timeline-dot ${dotClass}">${icon}</div>
          <div>
            <div class="timeline-text" style="${isCurrent ? 'color:var(--text);font-weight:700' : 'color:var(--text-muted)'}">${step}</div>
            ${timelineEvent ? `<div class="timeline-time">${new Date(timelineEvent.created_at).toLocaleString('pt-BR')}</div>` : ''}
          </div>
        </div>
      `;
    }).join('');

    resultDiv.innerHTML = `
      <div class="status-card">
        <div class="status-header">
          <div><strong>${order.protocol}</strong><br><span style="color:var(--text-muted);font-size:.8rem">${order.device} · ${order.service}</span></div>
          <span class="status-badge status-progress">${order.status}</span>
        </div>
        ${order.note && !order.note.includes('RECUSADO') ? `<div style="background:rgba(14,165,160,0.08);border-radius:8px;padding:.75rem;margin-bottom:1rem;font-size:.85rem;border-left:3px solid var(--secondary)">💬 <strong>Observação:</strong> ${order.note}</div>` : ''}
        <div class="timeline">${timelineHTML}</div>
        <div style="margin-top:1rem;font-size:.75rem;color:var(--text-muted)">Aberto em: ${new Date(order.created_at).toLocaleString('pt-BR')}</div>
      </div>
    `;
  } catch (error) {
    console.error('Erro:', error);
    resultDiv.innerHTML = '<div class="alert alert-error">❌ Erro de conexão. Verifique se o servidor está rodando.</div>';
  }
}

// Helper Functions
function showAlert(element, message, type) {
  element.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
  setTimeout(() => {
    if (element.innerHTML.includes(message)) {
      element.innerHTML = '';
    }
  }, 5000);
}

function toast(message, type = 'success') {
  const toastEl = document.getElementById('toast');
  toastEl.textContent = message;
  toastEl.className = `toast show toast-${type}`;
  setTimeout(() => toastEl.className = 'toast', 3000);
}

function scrollToRegister() {
  document.getElementById('register').scrollIntoView({ behavior: 'smooth' });
}

function scrollToTracking() {
  document.getElementById('tracking').scrollIntoView({ behavior: 'smooth' });
}

function toggleMobileMenu() {
  const menu = document.getElementById('mobileMenu');
  if (menu) menu.classList.toggle('open');
}

function closeMobileMenu() {
  const menu = document.getElementById('mobileMenu');
  if (menu) menu.classList.remove('open');
}

// Admin Panel Functions (serão sobrescritas pelo admin.js)
function openAdminPanel() {
  if (typeof window.openLoginModal === 'function') {
    window.openLoginModal();
  } else {
    console.error('Sistema administrativo não carregado. Verifique se o admin.js foi carregado.');
    alert('Sistema administrativo não disponível. Verifique se o servidor backend está rodando.');
  }
}