// Admin Panel JavaScript
const API_URL = 'http://localhost:3000/api';
let authToken = null;

// Check for existing session
const savedToken = localStorage.getItem('ccpa_admin_token');
if (savedToken) {
  authToken = savedToken;
}

// Modal management
function openLoginModal() {
  const modal = document.getElementById('loginModal');
  if (modal) {
    modal.classList.add('open');
    document.getElementById('loginAlert').innerHTML = '';
    document.getElementById('loginEmail').value = '';
    document.getElementById('loginPassword').value = '';
  }
}

function closeLoginModal() {
  const modal = document.getElementById('loginModal');
  if (modal) modal.classList.remove('open');
}

async function doLogin() {
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;
  const alertDiv = document.getElementById('loginAlert');

  if (!email || !password) {
    alertDiv.innerHTML = '<div class="alert alert-error">Preencha email e senha</div>';
    return;
  }

  try {
    const response = await fetch(`${API_URL}/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        email, 
        password,
        userAgent: navigator.userAgent
      })
    });

    const data = await response.json();

    if (response.ok && data.success) {
      authToken = data.token;
      localStorage.setItem('ccpa_admin_token', authToken);
      closeLoginModal();
      openAdminDashboard();
      toast('Login realizado com sucesso!', 'success');
    } else {
      alertDiv.innerHTML = `<div class="alert alert-error">❌ ${data.error || 'Credenciais inválidas'}</div>`;
    }
  } catch (error) {
    console.error('Erro no login:', error);
    alertDiv.innerHTML = '<div class="alert alert-error">Erro de conexão com o servidor</div>';
  }
}

function logout() {
  if (authToken) {
    fetch(`${API_URL}/admin/logout`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${authToken}` }
    }).catch(console.error);
  }
  authToken = null;
  localStorage.removeItem('ccpa_admin_token');
  closeAdminDashboard();
  toast('Sessão encerrada', 'success');
}

// Admin Dashboard
let adminInitialized = false;

function openAdminDashboard() {
  if (!authToken) {
    openLoginModal();
    return;
  }

  // Create admin panel if not exists
  if (!document.getElementById('adminPanel')) {
    createAdminPanel();
  }
  
  const panel = document.getElementById('adminPanel');
  if (panel) panel.style.display = 'block';
  document.body.style.overflow = 'hidden';
  
  if (!adminInitialized) {
    loadAdminStats();
    loadAdminOrders();
    loadAdminClients();
    loadBlockedUsers();
    loadSecurityLogs();
    loadSiteConfigAdmin();
    adminInitialized = true;
  }
}

function closeAdminDashboard() {
  const panel = document.getElementById('adminPanel');
  if (panel) panel.style.display = 'none';
  document.body.style.overflow = '';
}

function createAdminPanel() {
  const panel = document.createElement('div');
  panel.id = 'adminPanel';
  panel.className = 'admin-panel';
  panel.innerHTML = `
    <div class="admin-header">
      <div class="admin-header-left">
        <h2>⚙️ Painel Administrativo</h2>
        <span id="adminUserEmail">Administrador</span>
      </div>
      <button class="btn-sm btn-danger" onclick="window.logout()">Sair</button>
    </div>
    <div class="admin-layout">
      <div class="admin-sidebar">
        <div class="sidebar-item active" data-section="dashboard">📊 Dashboard</div>
        <div class="sidebar-item" data-section="orders">📋 Chamados</div>
        <div class="sidebar-item" data-section="clients">👥 Clientes</div>
        <div class="sidebar-item" data-section="blocked">🚫 Bloqueados</div>
        <div class="sidebar-item" data-section="config">⚙️ Configurações</div>
        <div class="sidebar-item" data-section="security">🛡️ Segurança</div>
      </div>
      <div class="admin-content">
        <div id="adminDashboard" class="admin-section active">
          <h3>Dashboard</h3>
          <div class="stats-grid" id="adminStats"></div>
          <h4 style="margin-top: 2rem;">Últimos Chamados</h4>
          <div class="table-container" id="recentOrdersTable"></div>
        </div>
        <div id="adminOrders" class="admin-section">
          <h3>Gestão de Chamados</h3>
          <input type="text" id="orderSearch" placeholder="🔍 Buscar por protocolo ou cliente..." class="search-input" oninput="window.loadAdminOrders()">
          <div class="table-container" id="ordersTable"></div>
        </div>
        <div id="adminClients" class="admin-section">
          <h3>Clientes Cadastrados</h3>
          <div class="table-container" id="clientsTable"></div>
        </div>
        <div id="adminBlocked" class="admin-section">
          <h3>Usuários Bloqueados</h3>
          <div class="table-container" id="blockedTable"></div>
          <div class="block-form">
            <h4>Bloquear Cliente</h4>
            <input type="text" id="blockPhone" placeholder="Telefone" class="search-input">
            <select id="blockType" class="search-input">
              <option value="permanent">Permanente</option>
              <option value="temporary">Temporário</option>
            </select>
            <input type="number" id="blockDays" placeholder="Dias (se temporário)" class="search-input" style="display:none">
            <textarea id="blockReason" placeholder="Motivo do bloqueio" rows="2" class="search-input"></textarea>
            <button class="btn btn-primary" onclick="window.blockClient()">🚫 Bloquear</button>
          </div>
        </div>
        <div id="adminConfig" class="admin-section">
          <h3>Configurações do Site</h3>
          <div id="configAlert"></div>
          <div class="config-form">
            <input type="text" id="configCompanyName" placeholder="Nome da Empresa" class="search-input">
            <input type="text" id="configAddress" placeholder="Endereço" class="search-input">
            <input type="email" id="configEmail" placeholder="Email" class="search-input">
            <input type="text" id="configInstagram" placeholder="Instagram" class="search-input">
            <input type="text" id="configHours" placeholder="Horário" class="search-input">
            <textarea id="configNotice" placeholder="Aviso no site" rows="3" class="search-input"></textarea>
            <button class="btn btn-primary" onclick="window.saveSiteConfig()">💾 Salvar Configurações</button>
          </div>
        </div>
        <div id="adminSecurity" class="admin-section">
          <h3>Log de Segurança</h3>
          <div class="table-container" id="securityTable"></div>
          <button class="btn-sm btn-danger" onclick="window.clearSecurityLogs()">🗑️ Limpar Log</button>
        </div>
      </div>
    </div>
  `;
  
  document.body.appendChild(panel);
  
  // Add click handlers for sidebar items
  document.querySelectorAll('.sidebar-item').forEach(item => {
    item.addEventListener('click', () => {
      const section = item.dataset.section;
      showAdminSection(section);
    });
  });
  
  // Add styles for admin panel
  addAdminStyles();
}

function addAdminStyles() {
  if (document.getElementById('adminStyles')) return;
  
  const style = document.createElement('style');
  style.id = 'adminStyles';
  style.textContent = `
    .admin-panel {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: var(--dark);
      z-index: 1000;
      display: none;
      overflow-y: auto;
    }
    .admin-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 2rem;
      background: var(--dark-100);
      border-bottom: 1px solid var(--border);
      position: sticky;
      top: 0;
      z-index: 10;
    }
    .admin-header-left h2 { font-size: 1.2rem; margin: 0; }
    .admin-header-left span { font-size: 0.75rem; color: var(--text-muted); }
    .admin-layout { display: flex; min-height: calc(100vh - 70px); }
    .admin-sidebar {
      width: 220px;
      background: var(--dark-100);
      border-right: 1px solid var(--border);
      padding: 1rem 0;
    }
    .sidebar-item {
      padding: 0.75rem 1.5rem;
      cursor: pointer;
      color: var(--text-muted);
      font-weight: 600;
      transition: all 0.2s;
      border-left: 3px solid transparent;
    }
    .sidebar-item:hover, .sidebar-item.active {
      background: rgba(26, 111, 196, 0.08);
      color: var(--text);
      border-left-color: var(--primary);
    }
    .admin-content {
      flex: 1;
      padding: 2rem;
      overflow-y: auto;
    }
    .admin-section { display: none; }
    .admin-section.active { display: block; }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 1rem;
      margin-bottom: 1rem;
    }
    .stat-card {
      background: var(--card-bg);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 1rem;
      text-align: center;
    }
    .stat-number { font-size: 2rem; font-weight: 900; color: var(--secondary); }
    .stat-label { font-size: 0.8rem; color: var(--text-muted); }
    .table-container {
      background: var(--card-bg);
      border: 1px solid var(--border);
      border-radius: 12px;
      overflow-x: auto;
      margin-top: 1rem;
    }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 0.75rem 1rem; text-align: left; font-size: 0.85rem; }
    th { color: var(--text-muted); border-bottom: 1px solid var(--border); }
    tr:hover td { background: rgba(14, 165, 160, 0.04); }
    .btn-sm {
      padding: 0.3rem 0.7rem;
      border-radius: 6px;
      font-size: 0.75rem;
      font-weight: 700;
      border: none;
      cursor: pointer;
      margin: 0 0.25rem;
    }
    .btn-edit { background: rgba(26, 111, 196, 0.15); color: #60a5fa; }
    .btn-delete { background: rgba(239, 68, 68, 0.15); color: var(--danger); }
    .btn-accept { background: rgba(34, 197, 94, 0.15); color: var(--success); }
    .btn-reject { background: rgba(239, 68, 68, 0.15); color: var(--danger); }
    .btn-danger { background: rgba(239, 68, 68, 0.15); color: var(--danger); }
    .search-input {
      background: rgba(5, 13, 26, 0.8);
      border: 1px solid var(--border);
      color: var(--text);
      padding: 0.5rem 1rem;
      border-radius: 8px;
      margin-bottom: 1rem;
      width: 100%;
      max-width: 300px;
    }
    .block-form {
      margin-top: 2rem;
      padding: 1.5rem;
      background: var(--card-bg);
      border: 1px solid var(--border);
      border-radius: 12px;
    }
    .config-form input, .config-form textarea {
      display: block;
      width: 100%;
      max-width: 500px;
      margin-bottom: 1rem;
    }
    @media (max-width: 768px) {
      .admin-sidebar { width: 60px; }
      .sidebar-item { text-align: center; font-size: 0; }
      .sidebar-item::before { font-size: 1.2rem; }
    }
  `;
  document.head.appendChild(style);
}

function showAdminSection(section) {
  document.querySelectorAll('.admin-section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.sidebar-item').forEach(s => s.classList.remove('active'));
  
  const sectionId = `admin${section.charAt(0).toUpperCase() + section.slice(1)}`;
  const targetSection = document.getElementById(sectionId);
  if (targetSection) targetSection.classList.add('active');
  
  const clickedItem = Array.from(document.querySelectorAll('.sidebar-item')).find(
    item => item.dataset.section === section
  );
  if (clickedItem) clickedItem.classList.add('active');
}

async function apiRequest(endpoint, options = {}) {
  if (!authToken) {
    throw new Error('Não autenticado');
  }
  
  const response = await fetch(`${API_URL}/admin/${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`,
      ...options.headers
    }
  });
  
  if (response.status === 401) {
    logout();
    throw new Error('Sessão expirada');
  }
  
  return response;
}

async function loadAdminStats() {
  try {
    const response = await apiRequest('stats');
    const stats = await response.json();
    
    const statsGrid = document.getElementById('adminStats');
    if (statsGrid) {
      statsGrid.innerHTML = `
        <div class="stat-card"><div class="stat-number">${stats.total || 0}</div><div class="stat-label">Total</div></div>
        <div class="stat-card"><div class="stat-number" style="color:var(--warning)">${stats.pending || 0}</div><div class="stat-label">Pendentes</div></div>
        <div class="stat-card"><div class="stat-number" style="color:#60a5fa">${stats.inRepair || 0}</div><div class="stat-label">Em Reparo</div></div>
        <div class="stat-card"><div class="stat-number" style="color:var(--success)">${stats.completed || 0}</div><div class="stat-label">Concluídos</div></div>
        <div class="stat-card"><div class="stat-number" style="color:var(--danger)">${stats.rejected || 0}</div><div class="stat-label">Recusados</div></div>
      `;
    }
    
    await loadRecentOrders();
  } catch (error) {
    console.error('Erro ao carregar stats:', error);
  }
}

async function loadRecentOrders() {
  try {
    const response = await apiRequest('orders?limit=10');
    const data = await response.json();
    
    const container = document.getElementById('recentOrdersTable');
    if (container && data.orders) {
      container.innerHTML = `
        <table>
          <thead>
            <tr><th>Protocolo</th><th>Cliente</th><th>Dispositivo</th><th>Status</th><th>Data</th></tr>
          </thead>
          <tbody>
            ${data.orders.map(order => `
              <tr>
                <td><code>${order.protocol}</code></td>
                <td>${escapeHtml(order.name)}</td>
                <td>${escapeHtml(order.device)}</td>
                <td><span class="status-badge status-progress">${order.status}</span></td>
                <td>${new Date(order.created_at).toLocaleDateString('pt-BR')}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }
  } catch (error) {
    console.error('Erro ao carregar chamados recentes:', error);
  }
}

async function loadAdminOrders() {
  const search = document.getElementById('orderSearch')?.value || '';
  try {
    const response = await apiRequest(`orders?search=${encodeURIComponent(search)}&limit=50`);
    const data = await response.json();
    
    const container = document.getElementById('ordersTable');
    if (container && data.orders) {
      container.innerHTML = `
        <table>
          <thead>
            <tr><th>Protocolo</th><th>Cliente</th><th>Telefone</th><th>Dispositivo</th><th>Serviço</th><th>Status</th><th>Ações</th></tr>
          </thead>
          <tbody>
            ${data.orders.map(order => `
              <tr>
                <td><code>${order.protocol}</code></td>
                <td>${escapeHtml(order.name)}</td>
                <td>${order.phone}</td>
                <td>${escapeHtml(order.device)}</td>
                <td>${escapeHtml(order.service)}</td>
                <td><span class="status-badge status-progress">${order.status}</span></td>
                <td>
                  <button class="btn-sm btn-edit" onclick="window.editOrder('${order.id}')">✏️ Editar</button>
                  <button class="btn-sm btn-delete" onclick="window.deleteOrder('${order.id}')">🗑️ Excluir</button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }
  } catch (error) {
    console.error('Erro ao carregar chamados:', error);
  }
}

async function loadAdminClients() {
  try {
    const response = await apiRequest('clients');
    const clients = await response.json();
    
    const container = document.getElementById('clientsTable');
    if (container) {
      container.innerHTML = `
        <table>
          <thead>
            <tr><th>Nome</th><th>Telefone</th><th>Chamados</th><th>Último Pedido</th><th>Status</th><th>Ações</th></tr>
          </thead>
          <tbody>
            ${clients.map(client => `
              <tr>
                <td>${escapeHtml(client.name)}</td>
                <td>${client.phone}</td>
                <td>${client.orders_count}</td>
                <td>${new Date(client.last_order).toLocaleDateString('pt-BR')}</td>
                <td><span class="status-badge ${client.is_blocked ? 'status-rejected' : 'status-done'}">${client.is_blocked ? 'Bloqueado' : 'Ativo'}</span></td>
                <td>
                  ${!client.is_blocked ? `<button class="btn-sm btn-delete" onclick="window.quickBlock('${client.phone}', '${escapeHtml(client.name)}')">🚫 Bloquear</button>` : `<button class="btn-sm btn-edit" onclick="window.unblockClient('${client.phone}')">🔓 Desbloquear</button>`}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }
  } catch (error) {
    console.error('Erro ao carregar clientes:', error);
  }
}

async function loadBlockedUsers() {
  try {
    const response = await apiRequest('blocked');
    const blocked = await response.json();
    
    const container = document.getElementById('blockedTable');
    if (container) {
      container.innerHTML = `
        <table>
          <thead>
            <tr><th>Telefone</th><th>Nome</th><th>Tipo</th><th>Expira em</th><th>Motivo</th><th>Ações</th></tr>
          </thead>
          <tbody>
            ${blocked.map(b => `
              <tr>
                <td>${b.phone}</td>
                <td>${escapeHtml(b.name || '—')}</td>
                <td>${b.type === 'permanent' ? '🔒 Permanente' : '⏰ Temporário'}</td>
                <td>${b.expires_at ? new Date(b.expires_at).toLocaleDateString('pt-BR') : '—'}</td>
                <td>${escapeHtml(b.reason || '—')}</td>
                <td><button class="btn-sm btn-edit" onclick="window.unblockClient('${b.phone}')">🔓 Desbloquear</button></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }
  } catch (error) {
    console.error('Erro ao carregar bloqueados:', error);
  }
}

async function loadSecurityLogs() {
  try {
    const response = await apiRequest('security-logs?limit=100');
    const logs = await response.json();
    
    const container = document.getElementById('securityTable');
    if (container) {
      container.innerHTML = `
        <table>
          <thead>
            <tr><th>Data/Hora</th><th>Email</th><th>Status</th><th>IP</th></tr>
          </thead>
          <tbody>
            ${logs.map(log => `
              <tr>
                <td>${new Date(log.created_at).toLocaleString('pt-BR')}</td>
                <td>${log.email}</td>
                <td><span class="status-badge ${log.status === 'success' ? 'status-done' : 'status-rejected'}">${log.status}</span></td>
                <td>${log.ip || '—'}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }
  } catch (error) {
    console.error('Erro ao carregar logs:', error);
  }
}

async function loadSiteConfigAdmin() {
  try {
    const response = await apiRequest('config');
    const config = await response.json();
    
    const companyName = document.getElementById('configCompanyName');
    const address = document.getElementById('configAddress');
    const email = document.getElementById('configEmail');
    const instagram = document.getElementById('configInstagram');
    const hours = document.getElementById('configHours');
    const notice = document.getElementById('configNotice');
    
    if (companyName) companyName.value = config.company_name || '';
    if (address) address.value = config.company_address || '';
    if (email) email.value = config.contact_email || '';
    if (instagram) instagram.value = config.instagram || '';
    if (hours) hours.value = config.business_hours || '';
    if (notice) notice.value = config.site_notice || '';
  } catch (error) {
    console.error('Erro ao carregar configurações:', error);
  }
}

async function saveSiteConfig() {
  const config = {
    company_name: document.getElementById('configCompanyName')?.value || '',
    company_address: document.getElementById('configAddress')?.value || '',
    contact_email: document.getElementById('configEmail')?.value || '',
    instagram: document.getElementById('configInstagram')?.value || '',
    business_hours: document.getElementById('configHours')?.value || '',
    site_notice: document.getElementById('configNotice')?.value || ''
  };
  
  try {
    const response = await apiRequest('config', {
      method: 'PUT',
      body: JSON.stringify(config)
    });
    
    if (response.ok) {
      const alertDiv = document.getElementById('configAlert');
      if (alertDiv) {
        alertDiv.innerHTML = '<div class="alert alert-success">✅ Configurações salvas!</div>';
        setTimeout(() => alertDiv.innerHTML = '', 3000);
      }
      toast('Configurações salvas!', 'success');
      loadSiteConfig(); // Reload public config
    }
  } catch (error) {
    console.error('Erro ao salvar configurações:', error);
    toast('Erro ao salvar configurações', 'error');
  }
}

async function editOrder(orderId) {
  const newStatus = prompt('Novo status do chamado:', 'Em Análise');
  if (!newStatus) return;
  
  try {
    const response = await apiRequest(`orders/${orderId}`, {
      method: 'PUT',
      body: JSON.stringify({ status: newStatus })
    });
    
    if (response.ok) {
      toast('Chamado atualizado!', 'success');
      loadAdminOrders();
      loadAdminStats();
    }
  } catch (error) {
    console.error('Erro ao editar chamado:', error);
    toast('Erro ao atualizar chamado', 'error');
  }
}

async function deleteOrder(orderId) {
  if (!confirm('Tem certeza que deseja excluir este chamado?')) return;
  
  try {
    const response = await apiRequest(`orders/${orderId}`, {
      method: 'DELETE'
    });
    
    if (response.ok) {
      toast('Chamado excluído!', 'success');
      loadAdminOrders();
      loadAdminStats();
    }
  } catch (error) {
    console.error('Erro ao excluir chamado:', error);
    toast('Erro ao excluir chamado', 'error');
  }
}

async function blockClient() {
  const phone = document.getElementById('blockPhone')?.value.trim();
  const type = document.getElementById('blockType')?.value;
  const days = parseInt(document.getElementById('blockDays')?.value);
  const reason = document.getElementById('blockReason')?.value.trim();
  
  if (!phone) {
    toast('Informe o telefone', 'error');
    return;
  }
  
  if (type === 'temporary' && (!days || days < 1)) {
    toast('Informe a quantidade de dias', 'error');
    return;
  }
  
  try {
    const response = await apiRequest('block', {
      method: 'POST',
      body: JSON.stringify({ phone, type, days, reason: reason || 'Comportamento inadequado' })
    });
    
    if (response.ok) {
      toast('Cliente bloqueado!', 'success');
      if (document.getElementById('blockPhone')) document.getElementById('blockPhone').value = '';
      if (document.getElementById('blockReason')) document.getElementById('blockReason').value = '';
      loadBlockedUsers();
      loadAdminClients();
    }
  } catch (error) {
    console.error('Erro ao bloquear cliente:', error);
    toast('Erro ao bloquear cliente', 'error');
  }
}

async function unblockClient(phone) {
  if (!confirm(`Desbloquear cliente ${phone}?`)) return;
  
  try {
    const response = await apiRequest(`unblock/${encodeURIComponent(phone)}`, {
      method: 'DELETE'
    });
    
    if (response.ok) {
      toast('Cliente desbloqueado!', 'success');
      loadBlockedUsers();
      loadAdminClients();
    }
  } catch (error) {
    console.error('Erro ao desbloquear cliente:', error);
    toast('Erro ao desbloquear cliente', 'error');
  }
}

function quickBlock(phone, name) {
  const phoneInput = document.getElementById('blockPhone');
  const reasonInput = document.getElementById('blockReason');
  const typeSelect = document.getElementById('blockType');
  const daysInput = document.getElementById('blockDays');
  
  if (phoneInput) phoneInput.value = phone;
  if (reasonInput) reasonInput.value = `Comportamento inadequado - ${name}`;
  if (typeSelect) typeSelect.value = 'temporary';
  if (daysInput) {
    daysInput.value = '30';
    daysInput.style.display = 'block';
  }
  
  // Scroll to block form
  document.querySelector('.block-form')?.scrollIntoView({ behavior: 'smooth' });
}

async function clearSecurityLogs() {
  if (!confirm('Limpar todos os logs de segurança?')) return;
  toast('Funcionalidade em desenvolvimento', 'error');
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function toast(message, type = 'success') {
  const toastEl = document.getElementById('toast');
  if (toastEl) {
    toastEl.textContent = message;
    toastEl.className = `toast show toast-${type}`;
    setTimeout(() => toastEl.className = 'toast', 3000);
  } else {
    alert(message);
  }
}

// Event listeners for block type selector
document.addEventListener('DOMContentLoaded', () => {
  const blockType = document.getElementById('blockType');
  const blockDays = document.getElementById('blockDays');
  
  if (blockType && blockDays) {
    blockType.addEventListener('change', (e) => {
      blockDays.style.display = e.target.value === 'temporary' ? 'block' : 'none';
    });
  }
});

// Expose functions globally
window.openLoginModal = openLoginModal;
window.closeLoginModal = closeLoginModal;
window.doLogin = doLogin;
window.logout = logout;
window.openAdminDashboard = openAdminDashboard;
window.closeAdminDashboard = closeAdminDashboard;
window.showAdminSection = showAdminSection;
window.loadAdminStats = loadAdminStats;
window.loadAdminOrders = loadAdminOrders;
window.loadAdminClients = loadAdminClients;
window.loadBlockedUsers = loadBlockedUsers;
window.loadSecurityLogs = loadSecurityLogs;
window.loadSiteConfigAdmin = loadSiteConfigAdmin;
window.saveSiteConfig = saveSiteConfig;
window.editOrder = editOrder;
window.deleteOrder = deleteOrder;
window.blockClient = blockClient;
window.unblockClient = unblockClient;
window.quickBlock = quickBlock;
window.clearSecurityLogs = clearSecurityLogs;
window.trackOrder = trackOrder;
window.registerOrder = registerOrder;
window.scrollToRegister = scrollToRegister;
window.scrollToTracking = scrollToTracking;
window.toggleMobileMenu = toggleMobileMenu;
window.closeMobileMenu = closeMobileMenu;
window.openAdminPanel = openLoginModal;