const express = require('express');
const { body, validationResult } = require('express-validator');
const { getDb } = require('../database');
const { v4: uuidv4 } = require('uuid');

const router = express.Router();

// Gerar protocolo único
async function generateProtocol() {
  const db = getDb();
  const year = new Date().getFullYear();
  const result = await db.get(
    "SELECT COUNT(*) as count FROM orders WHERE strftime('%Y', created_at) = ?",
    [year.toString()]
  );
  const number = String((result?.count || 0) + 1).padStart(5, '0');
  return `CCPA-${year}-${number}`;
}

// GET - Configurações do site
router.get('/config', async (req, res) => {
  try {
    const db = getDb();
    const configs = await db.all('SELECT key, value FROM site_config');
    const config = {};
    configs.forEach(c => { config[c.key] = c.value; });
    res.json(config);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro interno' });
  }
});

// POST - Abrir chamado
router.post('/orders', [
  body('name').trim().isLength({ min: 3 }).withMessage('Nome muito curto'),
  body('phone').trim().isLength({ min: 10 }).withMessage('Telefone inválido'),
  body('device').trim().isLength({ min: 2 }).withMessage('Dispositivo inválido'),
  body('service').trim().notEmpty().withMessage('Serviço obrigatório'),
  body('description').trim().isLength({ min: 5 }).withMessage('Descrição muito curta')
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const db = getDb();
  const { name, phone, device, service, description } = req.body;

  // Verificar se cliente está bloqueado
  const blocked = await db.get(
    `SELECT * FROM blocked_clients 
     WHERE phone = ? AND (expires_at IS NULL OR expires_at > datetime("now"))`,
    [phone]
  );

  if (blocked) {
    return res.status(403).json({ 
      error: 'Cliente bloqueado',
      reason: blocked.reason,
      expires: blocked.expires_at
    });
  }

  const protocol = await generateProtocol();
  const orderId = uuidv4();

  await db.run(
    `INSERT INTO orders (id, protocol, name, phone, device, service, description, status, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime("now"), datetime("now"))`,
    [orderId, protocol, name, phone, device, service, description, 'Aguardando Recebimento']
  );

  await db.run(
    `INSERT INTO order_timeline (order_id, event, description, created_at)
     VALUES (?, ?, ?, datetime("now"))`,
    [orderId, 'Chamado Aberto', 'Aguardando aprovação do administrador']
  );

  res.status(201).json({ 
    success: true, 
    protocol,
    message: 'Chamado aberto com sucesso'
  });
});

// GET - Rastrear chamado por protocolo
router.get('/track/:protocol', async (req, res) => {
  try {
    const db = getDb();
    const { protocol } = req.params;

    const order = await db.get(
      `SELECT id, protocol, name, phone, device, service, description, status, note, created_at, updated_at
       FROM orders WHERE protocol = ?`,
      [protocol.toUpperCase()]
    );

    if (!order) {
      return res.status(404).json({ error: 'Protocolo não encontrado' });
    }

    const timeline = await db.all(
      `SELECT event, description, created_at FROM order_timeline 
       WHERE order_id = ? ORDER BY created_at ASC`,
      [order.id]
    );

    // Não enviar dados sensíveis
    delete order.id;
    delete order.phone;

    res.json({ order, timeline });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro interno' });
  }
});

module.exports = router;