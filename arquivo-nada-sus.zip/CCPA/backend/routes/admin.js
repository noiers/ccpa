const express = require('express');
const { body, validationResult } = require('express-validator');
const { getDb } = require('../database');
const { 
  authenticateAdmin, 
  generateToken, 
  createSession,
  revokeSession,
  logSecurityAttempt,
  getFailedAttempts,
  verifyToken,
  validateSession
} = require('../auth');

const router = express.Router();

// Middleware de autenticação admin
async function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({ error: 'Token não fornecido' });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'Token inválido' });
  }

  const isValid = await validateSession(token);
  if (!isValid) {
    return res.status(401).json({ error: 'Sessão expirada' });
  }

  req.adminEmail = decoded.email;
  next();
}

// POST - Login admin
router.post('/login', async (req, res) => {
  const { email, password, ip, userAgent } = req.body;
  const clientIp = ip || req.ip || req.connection.remoteAddress;

  // Verificar tentativas
  const attempts = await getFailedAttempts(email);
  if (attempts >= 5) {
    await logSecurityAttempt(email, clientIp, 'blocked', userAgent);
    return res.status(429).json({ error: 'Muitas tentativas. Tente em 15 minutos.' });
  }

  const isValid = await authenticateAdmin(email, password);
  
  if (!isValid) {
    await logSecurityAttempt(email, clientIp, 'failed', userAgent);
    return res.status(401).json({ error: 'Credenciais inválidas' });
  }

  // Login bem sucedido
  const token = generateToken(email);
  await createSession(token, email);
  await logSecurityAttempt(email, clientIp, 'success', userAgent);

  res.json({ 
    success: true, 
    token,
    expiresIn: '7d'
  });
});

// POST - Logout
router.post('/logout', authMiddleware, async (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  await revokeSession(token);
  res.json({ success: true });
});

// GET - Dashboard stats
router.get('/stats', authMiddleware, async (req, res) => {
  const db = getDb();
  
  const total = await db.get('SELECT COUNT(*) as count FROM orders');
  const pending = await db.get(
    `SELECT COUNT(*) as count FROM orders 
     WHERE status IN ('Aguardando Recebimento', 'Em Análise', 'Aguardando Peça')`
  );
  const inRepair = await db.get(
    `SELECT COUNT(*) as count FROM orders WHERE status = 'Em Reparo'`
  );
  const completed = await db.get(
    `SELECT COUNT(*) as count FROM orders 
     WHERE status IN ('Pronto para Retirada', 'Entregue')`
  );
  const rejected = await db.get(
    `SELECT COUNT(*) as count FROM orders WHERE status = 'Recusado'`
  );

  res.json({
    total: total?.count || 0,
    pending: pending?.count || 0,
    inRepair: inRepair?.count || 0,
    completed: completed?.count || 0,
    rejected: rejected?.count || 0
  });
});

// GET - Listar chamados
router.get('/orders', authMiddleware, async (req, res) => {
  const db = getDb();
  const { search, status, page = 1, limit = 20 } = req.query;
  
  let query = 'SELECT * FROM orders WHERE 1=1';
  const params = [];
  
  if (search) {
    query += ' AND (protocol LIKE ? OR name LIKE ? OR phone LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  
  if (status && status !== 'todos') {
    query += ' AND status = ?';
    params.push(status);
  }
  
  query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  params.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
  
  const orders = await db.all(query, params);
  
  const totalResult = await db.get(
    'SELECT COUNT(*) as total FROM orders' + (search || status ? ' WHERE 1=1' : ''),
    params.slice(0, -2)
  );
  
  res.json({
    orders,
    total: totalResult?.total || 0,
    page: parseInt(page),
    limit: parseInt(limit)
  });
});

// GET - Chamado por ID
router.get('/orders/:id', authMiddleware, async (req, res) => {
  const db = getDb();
  const order = await db.get('SELECT * FROM orders WHERE id = ?', [req.params.id]);
  
  if (!order) {
    return res.status(404).json({ error: 'Chamado não encontrado' });
  }
  
  const timeline = await db.all(
    'SELECT * FROM order_timeline WHERE order_id = ? ORDER BY created_at ASC',
    [order.id]
  );
  
  res.json({ order, timeline });
});

// PUT - Atualizar chamado
router.put('/orders/:id', authMiddleware, [
  body('status').optional(),
  body('note').optional().isLength({ max: 500 })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const db = getDb();
  const { status, note } = req.body;
  const orderId = req.params.id;

  const order = await db.get('SELECT * FROM orders WHERE id = ?', [orderId]);
  if (!order) {
    return res.status(404).json({ error: 'Chamado não encontrado' });
  }

  if (status && status !== order.status) {
    await db.run(
      `INSERT INTO order_timeline (order_id, event, description, created_at)
       VALUES (?, ?, ?, datetime("now"))`,
      [orderId, `Status: ${status}`, `Alterado de "${order.status}" para "${status}"`]
    );
  }

  await db.run(
    `UPDATE orders SET status = COALESCE(?, status), note = COALESCE(?, note), updated_at = datetime("now")
     WHERE id = ?`,
    [status, note, orderId]
  );

  res.json({ success: true });
});

// DELETE - Excluir chamado
router.delete('/orders/:id', authMiddleware, async (req, res) => {
  const db = getDb();
  await db.run('DELETE FROM order_timeline WHERE order_id = ?', [req.params.id]);
  await db.run('DELETE FROM orders WHERE id = ?', [req.params.id]);
  res.json({ success: true });
});

// GET - Listar clientes
router.get('/clients', authMiddleware, async (req, res) => {
  const db = getDb();
  
  const clients = await db.all(`
    SELECT name, phone, COUNT(*) as orders_count, MAX(created_at) as last_order,
           (SELECT COUNT(*) FROM blocked_clients WHERE phone = orders.phone AND (expires_at IS NULL OR expires_at > datetime("now"))) as is_blocked
    FROM orders
    GROUP BY phone, name
    ORDER BY last_order DESC
  `);
  
  res.json(clients);
});

// POST - Bloquear cliente
router.post('/block', authMiddleware, [
  body('phone').notEmpty(),
  body('type').isIn(['permanent', 'temporary']),
  body('reason').optional(),
  body('days').optional().isInt({ min: 1, max: 365 })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const db = getDb();
  const { phone, name, type, reason, days } = req.body;
  
  let expiresAt = null;
  if (type === 'temporary' && days) {
    expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + days);
  }
  
  await db.run(
    `INSERT OR REPLACE INTO blocked_clients (phone, name, type, reason, expires_at, created_at)
     VALUES (?, ?, ?, ?, ?, datetime("now"))`,
    [phone, name || '', type, reason || 'Comportamento inadequado', expiresAt?.toISOString()]
  );
  
  res.json({ success: true });
});

// DELETE - Desbloquear cliente
router.delete('/unblock/:phone', authMiddleware, async (req, res) => {
  const db = getDb();
  await db.run('DELETE FROM blocked_clients WHERE phone = ?', [req.params.phone]);
  res.json({ success: true });
});

// GET - Listar bloqueados
router.get('/blocked', authMiddleware, async (req, res) => {
  const db = getDb();
  const blocked = await db.all(
    `SELECT * FROM blocked_clients 
     WHERE expires_at IS NULL OR expires_at > datetime("now")
     ORDER BY created_at DESC`
  );
  res.json(blocked);
});

// GET - Logs de segurança
router.get('/security-logs', authMiddleware, async (req, res) => {
  const db = getDb();
  const { limit = 100 } = req.query;
  const logs = await db.all(
    `SELECT * FROM security_logs ORDER BY created_at DESC LIMIT ?`,
    [parseInt(limit)]
  );
  res.json(logs);
});

// GET - Configurações do site
router.get('/config', authMiddleware, async (req, res) => {
  const db = getDb();
  const configs = await db.all('SELECT key, value FROM site_config');
  const config = {};
  configs.forEach(c => { config[c.key] = c.value; });
  res.json(config);
});

// PUT - Atualizar configurações
router.put('/config', authMiddleware, async (req, res) => {
  const db = getDb();
  const updates = req.body;
  
  for (const [key, value] of Object.entries(updates)) {
    await db.run(
      `INSERT OR REPLACE INTO site_config (key, value, updated_at) VALUES (?, ?, datetime("now"))`,
      [key, value]
    );
  }
  
  res.json({ success: true });
});

module.exports = { router, authMiddleware };