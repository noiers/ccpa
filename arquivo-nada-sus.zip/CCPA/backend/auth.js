const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { getDb } = require('./database');

const JWT_SECRET = process.env.JWT_SECRET || 'ccpa_secret_key';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'jonassilveira2007@gmail.com';
// Hash para "CCPA@2007" - em produção, gere com bcrypt.hashSync('CCPA@2007', 10)
const ADMIN_PASSWORD_HASH = '$2a$10$N9qo8uLOickgx2ZMRZoMy.MrAJJqK9XkR5XrE5XrE5XrE5XrE5XrE';

function generateToken(email) {
  return jwt.sign({ email, role: 'admin' }, JWT_SECRET, { expiresIn: '7d' });
}

function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
}

async function authenticateAdmin(email, password) {
  if (email !== ADMIN_EMAIL) return false;
  return bcrypt.compareSync(password, ADMIN_PASSWORD_HASH);
}

async function validateSession(token) {
  const db = getDb();
  const session = await db.get(
    'SELECT * FROM admin_sessions WHERE token = ? AND expires_at > datetime("now")',
    [token]
  );
  return !!session;
}

async function createSession(token, email) {
  const db = getDb();
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 7);
  
  await db.run(
    'INSERT INTO admin_sessions (token, email, expires_at) VALUES (?, ?, ?)',
    [token, email, expiresAt.toISOString()]
  );
}

async function revokeSession(token) {
  const db = getDb();
  await db.run('DELETE FROM admin_sessions WHERE token = ?', [token]);
}

async function logSecurityAttempt(email, ip, status, userAgent) {
  const db = getDb();
  await db.run(
    'INSERT INTO security_logs (email, ip, status, user_agent) VALUES (?, ?, ?, ?)',
    [email, ip, status, userAgent]
  );
}

async function getFailedAttempts(email, minutes = 15) {
  const db = getDb();
  const result = await db.get(
    `SELECT COUNT(*) as count FROM security_logs 
     WHERE email = ? AND status = 'failed' 
     AND created_at > datetime("now", ?)`,
    [email, `-${minutes} minutes`]
  );
  return result?.count || 0;
}

module.exports = {
  generateToken,
  verifyToken,
  authenticateAdmin,
  validateSession,
  createSession,
  revokeSession,
  logSecurityAttempt,
  getFailedAttempts
};