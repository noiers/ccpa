const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const path = require('path');

let db;

async function initializeDatabase() {
  db = await open({
    filename: path.join(__dirname, 'ccpa.db'),
    driver: sqlite3.Database
  });

  // Tabela de chamados
  await db.exec(`
    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      protocol TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      device TEXT NOT NULL,
      service TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Aguardando Recebimento',
      note TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Tabela de timeline
  await db.exec(`
    CREATE TABLE IF NOT EXISTS order_timeline (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id TEXT NOT NULL,
      event TEXT NOT NULL,
      description TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    )
  `);

  // Tabela de clientes bloqueados
  await db.exec(`
    CREATE TABLE IF NOT EXISTS blocked_clients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT NOT NULL UNIQUE,
      name TEXT,
      type TEXT NOT NULL,
      reason TEXT,
      expires_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Tabela de configurações do site
  await db.exec(`
    CREATE TABLE IF NOT EXISTS site_config (
      key TEXT PRIMARY KEY,
      value TEXT,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Tabela de logs de segurança
  await db.exec(`
    CREATE TABLE IF NOT EXISTS security_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT,
      ip TEXT,
      status TEXT,
      user_agent TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Tabela de sessões admin
  await db.exec(`
    CREATE TABLE IF NOT EXISTS admin_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      token TEXT NOT NULL,
      email TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      expires_at DATETIME NOT NULL
    )
  `);

  // Inserir configurações padrão se não existirem
  const defaultConfig = [
    ['company_name', 'CCPA - Cell Consertos Porto Amazonas'],
    ['company_address', 'R. Otávio de Souza Brito, 43, Porto Amazonas - PR, 84140-000'],
    ['contact_email', 'cell.consertos.pa@gmail.com'],
    ['contact_phone', '(42) 99999-9999'],
    ['instagram', '@cell.conserto.pa'],
    ['business_hours', 'Aberto 24 horas'],
    ['site_notice', '']
  ];

  for (const [key, value] of defaultConfig) {
    await db.run(
      'INSERT OR IGNORE INTO site_config (key, value) VALUES (?, ?)',
      [key, value]
    );
  }

  console.log('✅ Banco de dados inicializado');
  return db;
}

function getDb() {
  if (!db) throw new Error('Database not initialized');
  return db;
}

module.exports = { initializeDatabase, getDb };